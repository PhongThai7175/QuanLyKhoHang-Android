package com.example.App_quanlykho.utilities;

import com.example.App_quanlykho.model.HoaDon;

public interface ItemHoaDonClick {
    void ItemClick(HoaDon hoaDon);
}
