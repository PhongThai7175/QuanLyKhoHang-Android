package com.example.App_quanlykho.utilities;

import com.example.App_quanlykho.model.SanPham;

public interface ItemSanPhamClick {
    void ItemClick(SanPham sanPham);
}
