package com.example.App_quanlykho.utilities;

import com.example.App_quanlykho.model.KhachHang;

public interface ItemKhachHangClick {
    void OnItemClick(KhachHang khachHang);
}
